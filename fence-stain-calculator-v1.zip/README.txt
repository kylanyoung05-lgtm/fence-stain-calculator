FENCE STAIN CALCULATOR — FIRST VERSION

Open index.html in a browser to test the calculator.

Next production steps:
1. Buy/connect a domain.
2. Deploy the HTML site.
3. Add Google Search Console + analytics.
4. Add dedicated SEO pages for fence stain, fence paint, cedar fence, 100/200/300 ft examples, and fence staining cost.
5. Add affiliate links only after confirming the relevant affiliate programs.
6. Add a fence staining cost / lead-gen calculator as the next major feature.
